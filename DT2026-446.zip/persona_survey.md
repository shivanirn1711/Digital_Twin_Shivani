# Consumer profile — participant DT2026-446

Source: 115-item Digital Twin questionnaire (dtlab-persona-v1).
Cite item codes verbatim when using these facts in the decision log.
Likert answers: 1=Disagree strongly ... 5=Agree strongly.
Items marked [CONSTRAINT] are inviolable rules, never preferences.
5 sensitive demographic items excluded at the participant's request.

## Demographics

- **D01** Which state or union territory do you currently live in?  
  → Maharashtra
- **D02** Which city do you currently live in?  
  → Mumbai
- **D03** How would you classify your city?  
  → Metro (Tier 1)
- **D05** How old are you? (in years, number only)  
  → 25
- **D06** Your age group:  
  → 25-29
- **D07** What is the highest level of schooling or degree that you have completed?  
  → Master's degree (enrolled)
- **D08** Which of these best describes you?  
  → Never been married
- **D13** Including yourself, how many people currently live in your household?  
  → 4
- **D14** What is your current employment status?  
  → Student
- **D15** Which languages do you browse and shop in online?  
  → English, Tamil
## Big Five Personality

- **BF01** I see myself as someone who is full of energy  
  → 3 - Neither agree nor disagree
- **BF02** I see myself as someone who is emotionally stable, not easily upset  
  → 4 - Agree a little
- **BF03** I see myself as someone who does things efficiently  
  → 4 - Agree a little
- **BF04** I see myself as someone who is outgoing, sociable  
  → 2 - Disagree a little
- **BF05** I see myself as someone who is sophisticated in art, music, or literature  
  → 4 - Agree a little
- **BF06** I see myself as someone who is considerate and kind to almost everyone  
  → 5 - Agree strongly
- **BF07** I see myself as someone who is generally trusting  
  → 5 - Agree strongly
## Need for Cognition

- **NC01** I would prefer complex to simple problems  
  → 3 - Neither agree nor disagree
- **NC02** I find satisfaction in deliberating hard and for long hours  
  → 2 - Disagree a little
- **NC03** I prefer my life to be filled with puzzles that I must solve  
  → 5 - Agree strongly
## Agentic and Communal Values

- **AC01** How important is WEALTH (financially successful, prosperous) as a guiding principle in your life?  
  → Extremely important
- **AC02** How important is PLEASURE (having one's fill of life's pleasures and enjoyments) as a guiding principle in your life?  
  → Extremely important
- **AC03** How important is INFLUENCE (having impact, influencing people and events) as a guiding principle in your life?  
  → Somewhat important
- **AC04** How important is COMPETENCE (displaying mastery, being capable, effective) as a guiding principle in your life?  
  → Quite important
- **AC05** How important is ACHIEVEMENT (reaching lofty goals) as a guiding principle in your life?  
  → Extremely important
- **AC06** How important is LOYALTY (being faithful to friends, family, and group) as a guiding principle in your life?  
  → Extremely important
- **AC07** How important is POWER (control over others, dominance) as a guiding principle in your life?  
  → Quite important
- **AC08** How important is EXCITEMENT (seeking adventure, risk, an exciting lifestyle) as a guiding principle in your life?  
  → Extremely important
- **AC09** How important is STATUS (high rank, wide respect) as a guiding principle in your life?  
  → Extremely important
- **AC10** How important is AUTONOMY (independent, free of others' control) as a guiding principle in your life?  
  → Extremely important
- **AC11** How important is RECOGNITION (becoming notable, famous, or admired) as a guiding principle in your life?  
  → Extremely important
- **AC12** How important is SUPERIORITY (defeating the competition, standing on top) as a guiding principle in your life?  
  → Moderately important
## Consumer Minimalism

- **MIN01** I avoid accumulating lots of stuff  
  → 2 - Disagree a little
- **MIN02** I restrict the number of things I own  
  → 2 - Disagree a little
- **MIN03** I actively avoid acquiring excess possessions  
  → 1 - Disagree strongly
- **MIN04** The selection of things I own has been carefully curated  
  → 3 - Neither agree nor disagree
## Green Values

- **GV01** It is important to me that the products I use do not harm the environment  
  → 3 - Neither agree nor disagree
- **GV02** My purchase habits are affected by my concern for our environment  
  → 3 - Neither agree nor disagree
- **GV03** I am willing to be inconvenienced in order to take actions that are more environmentally friendly  
  → 3 - Neither agree nor disagree
## Social Desirability

- **SDS01** I sometimes feel resentful when I don't get my way  
  → FALSE
- **SDS02** There have been times when I felt like rebelling against people in authority even though I knew they were right  
  → FALSE
- **SDS03** There have been occasions when I took advantage of someone  
  → FALSE
- **SDS04** There have been times when I was quite jealous of the good fortune of others  
  → TRUE
## Individualism and Collectivism

- **IC01** I rely on myself most of the time, I rarely rely on others  
  → 4 - Agree a little
- **IC02** I often do my own thing  
  → 4 - Agree a little
- **IC03** My personal identity, independent of others, is very important to me  
  → 5 - Agree strongly
- **IC04** It is important for me to do my job better than the others  
  → 3 - Neither agree nor disagree
## Regulatory Focus

- **RF01** Rules and regulations are helpful and necessary for me  
  → TRUE
- **RF02** I'm not bothered about reviewing or checking things really closely  
  → Probably not true
- **RF03** I like to do things in a new way  
  → Definitely untrue
- **RF04** I like trying out lots of different things, and am often successful in doing so  
  → TRUE
## Spending Habits

- **TS01** Which of the following best describes your spending habits?  
  → About the same or neither
- **TS02** Some people have trouble limiting their spending: they often spend money - for example on clothes, meals, vacations - when they would do better not to. How well does this description fit you?  
  → Sometimes
- **TS03** Other people have trouble spending money. Perhaps because spending money makes them anxious, they often don't spend money on things they should spend it on. How well does this description fit you?  
  → Rarely
- **TS04** Mr. A is accompanying a good friend on a shopping spree at a local mall. In a large department store with a "one-day-only sale" (everything 10-60% off), he realizes he doesn't need anything, yet can't resist and ends up spending almost ₹8,000 on stuff. Mr. B, in the same situation, figures he can get great deals on items he needs, yet the thought of spending the money keeps him from buying. In terms of your own behavior, who are you more similar to?  
  → Somewhat like A
## Need for Uniqueness

- **NU01** I often combine possessions in such a way that I create a personal image that cannot be duplicated  
  → 3 - Neither agree nor disagree
- **NU02** Having an eye for products that are interesting and unusual assists me in establishing a distinctive image  
  → 4 - Agree a little
- **NU03** When it comes to the products I buy and the situations in which I use them, I have broken customs and rules  
  → 1 - Disagree strongly
- **NU04** When a product I own becomes popular among the general population, I begin to use it less  
  → 1 - Disagree strongly
## Self-Monitoring

- **SM01** In social situations, I have the ability to alter my behavior if I feel that something else is called for  
  → 4 - Agree a little
- **SM02** I have the ability to control the way I come across to people, depending on the impression I wish to give them  
  → 4 - Agree a little
- **SM03** I have found that I can adjust my behavior to meet the requirements of any situation I find myself in  
  → 4 - Agree a little
- **SM04** My powers of intuition are quite good when it comes to understanding others' emotions and motives  
  → 4 - Agree a little
## Maximization

- **MAX01** I often find it difficult to shop for a gift for a friend  
  → 5 - Agree strongly
- **MAX02** When shopping, I have a hard time finding clothing that I really love  
  → 2 - Disagree a little
- **MAX03** No matter what I do, I have the highest standards for myself  
  → 4 - Agree a little
- **MAX04** I never settle for second best  
  → 4 - Agree a little
## Amazon.in Shopping Behavior

- **CB01** How many online orders do you place in a typical month (all platforms)?  
  → 2-4
- **CB02** What share of your online shopping happens on Amazon.in (vs. Flipkart/Myntra/quick-commerce/others)?  
  → About half
- **CB03** What is your typical single-order value on Amazon.in?  
  → ₹700-1,500
- **CB04** Which categories do you buy online most often? (pick up to 3)  
  → Electronics, Books/media, Home/kitchen
- **CB05** Do you have an Amazon Prime membership?  
  → Yes - shared/family
- **CB06** How long do you research before buying electronics over ₹2,000?  
  → Under an hour
- **CB07** Before buying, do you compare prices across platforms?  
  → Usually
- **CB08** If the same item costs ₹50 less but arrives 3 days later - which do you pick?  
  → Pricier and faster
- **CB09** How often do you return items you bought online?  
  → Rarely (under 10%)
- **CB10** How many reviews do you typically read before buying something new?  
  → Many (6-20)
- **CB11** What star rating is your minimum for an unfamiliar product?  
  → 4.3+
- **CB12** Do you write reviews yourself?  
  → Only when angry
- **CB13** Do you notice or avoid "Sponsored" listings in search results?  
  → I notice but don't mind
- **CB14** When a product has an "Amazon's Choice" or "Bestseller" badge, you...  
  → Ignore badges
- **CB15** How do you usually sort or filter search results?  
  → By rating
- **CB16** During big sale events (Great Indian Festival / Prime Day) you typically...  
  → Browse and buy opportunistically
- **CB17** How often do you abandon a cart without buying?  
  → Often
- **CB18** Do you use EMI / pay-later options for larger purchases?  
  → Never
- **CB19** How many gifts do you buy online per year?  
  → 7-12
- **CB20** Which device do you mainly shop on?  
  → Phone app
- **CB21** Delivery to your address is typically...  
  → 2-3 days
- **CB22** Which category would you NEVER buy online, and why?  
  → Large Electronic Appliances
## Values and Constraints

- **VC01** **[CONSTRAINT]** Dietary practice (affects food/supplement purchases):  
  → Eggetarian
- **VC02** **[CONSTRAINT]** Allergies or ingredients you must avoid:  
  → None
- **VC03** **[CONSTRAINT]** Materials you avoid (e.g., leather, fur, specific metals):  
  → None
- **VC04** **[CONSTRAINT]** Ethical exclusions (e.g., no animal testing, no fast fashion):  
  → None
- **VC05** **[CONSTRAINT]** Brands you personally boycott or refuse to buy - and why:  
  → None
- **VC06** Fragrance sensitivity (perfumed products)?  
  → Mild only
- **VC07** Would you accept a certified refurbished product at 30% off?  
  → No
- **VC08** How important is warranty/after-sales service to you?  
  → Dealbreaker
- **VC09** Your aesthetic leans...  
  → No consistent aesthetic
- **VC10** Colors you gravitate toward in products/clothing:  
  → Blues, Pinks, Black, White etc.
- **VC11** Maximum delivery wait you accept for non-urgent items:  
  → 1 week
- **VC12** Sizes you buy (clothing/shoe), if applicable:  
  → S and 6 (UK)
## Predictive Preferences

- **PR01** You get ₹2,000 guilt-free right now. Which category does it go to?  
  → Fashion
- **PR03** Your dream "small splurge" under ₹10,000 would be:  
  → An entire makeup set
- **PR04** The single item you have repurchased most often online:  
  → Lotion
- **PR05** One brand you would never switch away from - and for what product:  
  → Vaseline - Peteoleum Jelly
- **PR06** A category where the cheapest option always wins for you:  
  → Food Items
- **PR07** A category where you always go premium:  
  → Perfumes
- **PR09** Describe the birthday gift (max ₹1,500) you would buy your closest friend, and why:  
  → A bracelet
